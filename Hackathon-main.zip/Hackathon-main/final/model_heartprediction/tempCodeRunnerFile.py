
# l_model = LinearRegression()

# l_model.fit(X_train, y_train)

# print("Training Accuracy of linear: ",l_model.score(X_train, y_train))

# y_pred = l_model.predict(X_test)

# print("Test Accuracy of linear: ",accuracy_score(y_test, y_pred))
