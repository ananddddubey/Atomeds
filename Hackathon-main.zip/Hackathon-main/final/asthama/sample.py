import tensorflow as tf
print(tf.__version__)  # This will print the installed TensorFlow version
